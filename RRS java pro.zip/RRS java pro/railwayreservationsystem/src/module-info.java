/**
 * 
 */
/**
 * 
 */
module railwayreservationsystem {
	requires java.sql;
}