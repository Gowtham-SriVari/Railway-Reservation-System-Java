package railwayreservationsystem;

	import java.sql.Connection;
	import java.sql.DriverManager;

	public class jdbcconnection {

	    private static final String url ="jdbc:mysql://localhost:3306/railway";
	    private static final String user = "root";
	    private static final String password = "1995";

	    public static Connection getConnection() throws Exception {
	        return DriverManager.getConnection(url, user, password);
	    }
	}

