package railwayreservationsystem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class billservice {

	    public static void billdetails() {

	        try {

	            Connection con = jdbcconnection.getConnection();
	            Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery("select p.passid,p.passname,p.passage,p.passgender," +
	                    "t.tikid,t.bookingdate,t.journeydate,t.seatsbookes," +
	                    "tr.trainname,tr.price " +"from passengers p " +
	                    "join tickets t on p.passid=t.passid " +
	                    "join trains tr on t.trainid=tr.trainid");

	            System.out.println("----- BILL DETAILS -----");

	            while (rs.next()) {

	                double price = rs.getDouble("price");
	                int seats = rs.getInt("seatsbookes");
	                double total = price * seats;

	                System.out.println("Passenger ID : "+ rs.getInt("passid"));
	                System.out.println("Passenger Name : "+ rs.getString("passname"));
	                System.out.println("Age : "+ rs.getInt("passage"));
	                System.out.println("Gender : "+ rs.getString("passgender"));
	                System.out.println("Ticket ID : "+ rs.getInt("tikid"));
	                System.out.println("Train Name : "+ rs.getString("trainname"));
	                System.out.println("Booking Date : "+ rs.getString("bookingdate"));
	                System.out.println("Journey Date : "+ rs.getString("journeydate"));
	                System.out.println("Seats Booked : "+ seats);
	                System.out.println("Price Per Seat : "+ price);
	                System.out.println("Total Amount : ₹"+ total);
	                System.out.println("------------------------");
	            }

	        } 
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }
	}

