package railwayreservationsystem;

import java.util.Scanner;

public class railwayreservationsystem {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int choice = 0;

        while (choice != 6) {

            System.out.println("---WELCOME TO RAILWAY RESERVATION SYSTEM---");
            System.out.println("1. View Trains");
            System.out.println("2. Add Passenger");
            System.out.println("3. Book Tickets");
            System.out.println("4. View Tickets");
            System.out.println("5. Cancel Ticket");
            System.out.println("6. Bill Details");

            System.out.print("Enter Your Choice : ");
            choice = scan.nextInt();

            switch (choice) {

                case 1:
                    trainservice.viewtrains();
                    break;

                case 2:
                    passengerservice.addPassenger();
                    break;

                case 3:
                    ticketservice.bookTickets();
                    break;

                case 4:
                    ticketservice.viewTickets();
                    break;

                case 5:
                    ticketservice.cancelTickets();
                    break;

                case 6:
                    billservice.billdetails();
                    System.out.println("Thank You For Using Railway Reservation System");
                    break;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}