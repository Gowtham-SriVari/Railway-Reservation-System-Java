package railwayreservationsystem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class trainservice {
	
	    public static void viewtrains() {

	        try {
	        	
	            Connection con = jdbcconnection.getConnection();
	            Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery("select * from trains");

	            System.out.println("----- TRAINS -----");

	            while (rs.next()) {

	                System.out.println(rs.getInt("trainid") + " " +rs.getString("trainname") + " " +
	                        rs.getString("startsfrom") + " " +rs.getString("destination") + " " +
	                        rs.getInt("totalseats") + " " +rs.getInt("availableseats") + " " +rs.getDouble("price"));
	            }

	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }
	}

