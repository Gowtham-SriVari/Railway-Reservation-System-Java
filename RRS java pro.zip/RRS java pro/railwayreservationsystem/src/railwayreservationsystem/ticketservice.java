package railwayreservationsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class ticketservice {

	    public static void bookTickets() {

	        try {

	            Scanner scan = new Scanner(System.in);
	            System.out.print("Enter Passenger ID : ");
	            int passid = scan.nextInt();

	            System.out.print("Enter Train ID : ");
	            int trainid = scan.nextInt();
	            scan.nextLine();

	            System.out.print("Enter Booking Date (YYYY-MM-DD) : ");
	            String bookingdate = scan.nextLine();

	            System.out.print("Enter Journey Date (YYYY-MM-DD) : ");
	            String journeydate = scan.nextLine();

	            System.out.print("Enter Number Of Seats : ");
	            int seatsbookes = scan.nextInt();

	            Connection con = jdbcconnection.getConnection();
	            PreparedStatement ps = con.prepareStatement("insert into tickets(passid,trainid,bookingdate,journeydate,seatsbookes) values (?,?,?,?,?)");
	            ps.setInt(1, passid);
	            ps.setInt(2, trainid);
	            ps.setString(3, bookingdate);
	            ps.setString(4, journeydate);
	            ps.setInt(5, seatsbookes);
	            int rows = ps.executeUpdate();

	            if (rows > 0) {
	                System.out.println("Ticket Booked Successfully");
	            }

	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }

	    public static void viewTickets() {

	        try {

	            Connection con = jdbcconnection.getConnection();
	            Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery("select * from tickets");

	            System.out.println("----- TICKETS -----");

	            while (rs.next()) {

	                System.out.println("Ticket ID : " + rs.getInt("tikid") +" Train ID : " + rs.getInt("trainid") +
	                        " Passenger ID : " + rs.getInt("passid") +" Journey Date : " + rs.getString("journeydate") +
	                        " Seats Booked : " + rs.getInt("seatsbookes"));
	            }

	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }

	    public static void cancelTickets() {

	        try {

	            Scanner scan = new Scanner(System.in);
	            System.out.print("Enter Ticket ID To Cancel : ");	            
	            int tikid = scan.nextInt();
	            
	            Connection con = jdbcconnection.getConnection();
	            PreparedStatement ps1 = con.prepareStatement("select trainid,seatsbookes from tickets where tikid=?");
	            ps1.setInt(1, tikid);
	            ResultSet rs = ps1.executeQuery();

	            if (rs.next()) {

	                int trainid = rs.getInt("trainid");
	                int seats = rs.getInt("seatsbookes");

	                PreparedStatement ps2 = con.prepareStatement("delete from tickets where tikid=?");
	                ps2.setInt(1, tikid);
	                int rows = ps2.executeUpdate();

	                if (rows > 0) {

	                    PreparedStatement ps3 = con.prepareStatement("update trains set availableseats=availableseats+? where trainid=?");
	                    ps3.setInt(1, seats);
	                    ps3.setInt(2, trainid);
	                    ps3.executeUpdate();

	                    System.out.println("Ticket Cancelled Successfully");
	                }

	            }
	            else {

	                System.out.println("Ticket Not Found");
	            }

	        } 
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }
	}

