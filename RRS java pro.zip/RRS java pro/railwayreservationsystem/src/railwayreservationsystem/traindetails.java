package railwayreservationsystem;

import java.sql.DriverManager;

public class traindetails {

	public static void main(String[] args) {
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/railway","root","1995")
		}

	}

}
