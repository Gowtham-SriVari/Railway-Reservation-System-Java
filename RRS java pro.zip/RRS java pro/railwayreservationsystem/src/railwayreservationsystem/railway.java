package railwayreservationsystem;

public class railway {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
