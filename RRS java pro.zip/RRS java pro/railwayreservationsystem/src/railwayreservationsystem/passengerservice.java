package railwayreservationsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class passengerservice {


	    public static void addPassenger() {

	        try {

	            Scanner scan = new Scanner(System.in);

	            System.out.print("Enter Passenger Name : ");
	            String name = scan.nextLine();

	            System.out.print("Enter Passenger Age : ");
	            int age = scan.nextInt();

	            System.out.print("Enter Passenger Gender : ");
	            String gender = scan.next();

	            Connection con = jdbcconnection.getConnection();

	            PreparedStatement ps = con.prepareStatement("insert into passengers(passname,passage,passgender) values (?,?,?)");

	            ps.setString(1, name);
	            ps.setInt(2, age);
	            ps.setString(3, gender);
	            int rows = ps.executeUpdate();

	            if (rows > 0) {
	                System.out.println("Passenger Added Successfully");
	            }

	        } 
	        catch (Exception e) {
	            System.out.println(e);
	        }
	    }
	}

